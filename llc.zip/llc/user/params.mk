## MANDATORY PARAMETERS ##

RESULTS = llc

## USER-UPDATED PARAMETERS ##

ORGANISM = human

CC_CORRECTION = false
BINARIZATION_FILE = llc/bin/mstates_bin.csv
YAML_MODEL = llc/user/spec.yml

GRN_DATABASE = dorothea
# INFER_LIMIT = 100
