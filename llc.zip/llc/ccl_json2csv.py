#!/usr/bin/env python

import warnings
warnings.filterwarnings("ignore")

from pathlib import Path

import pandas as pd
import bonesistools as bt
import json

class Options:
    def __init__(self, **kwargs):
        for k,v in kwargs.items():
            self.__dict__[k] = v

opt = Options(
    input=Path("ccl/bin/mstates_bin.json"),
    output=Path("ccl/bin/mstates_bin.csv"),
)

with open(opt.input) as f:
    bin_mstates_d = json.load(f)

bin_mstates = pd.DataFrame.from_dict(bin_mstates_d, orient="index", dtype=float)
bin_mstates.index.name = "macrostate"

genesyn = bt.dbs.ncbi.GeneSynonyms(organism="human")
genesyn.standardize_df(bin_mstates, axis=1, copy=False)

bin_mstates.to_csv(
    opt.output,
    sep=",",
    index=True
)